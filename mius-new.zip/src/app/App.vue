<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style>
  #app {
    -webkit-user-select: none;
  }

  ::-webkit-scrollbar {
    display: none;
  }
</style>