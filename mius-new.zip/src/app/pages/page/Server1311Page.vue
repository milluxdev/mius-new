<template>
  <div class="serve-info">
    <Server name="server1311"  label="YGOPRO 1311"/>
  </div>
</template>
<script>
import Server from "../component/Server";
export default {
  name: "Server1311",
  components: {
    Server
  }
};
</script>
