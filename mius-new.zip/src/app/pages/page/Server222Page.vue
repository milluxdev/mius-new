<template>
  <div class="serve-info">
    <Server name="server222"  label="YGOPRO 222"/>
  </div>
</template>
<script>
import Server from "../component/Server";
export default {
  name: "Server222",
  components: {
    Server
  }
};
</script>
