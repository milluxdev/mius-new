<template>
  <div class="serve-info">
    <Server name="server7210" label="YGOPRO 7210"/>
  </div>
</template>
<script>
import Server from "../component/Server";
export default {
  name: "Server7210",
  components: {
    Server
  }
};
</script>
