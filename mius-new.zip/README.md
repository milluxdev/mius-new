# Mius-New

## Project setup
```
npm install
```

### Local run project
```
npm run dev
```

### Build project
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
